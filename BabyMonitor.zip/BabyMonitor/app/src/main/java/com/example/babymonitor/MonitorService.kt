package com.example.babymonitor

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.net.wifi.WifiManager
import android.os.*
import java.net.*
import kotlin.concurrent.thread
import kotlin.math.sqrt

class MonitorService : Service() {
    companion object {
        const val PORT = 8888
        const val RATE = 16000
        @Volatile var threshold = 50
        @Volatile var level = 0
        @Volatile var levelListener: ((Int) -> Unit)? = null
        @Volatile var status = "Выберите режим"
        @Volatile var listener: ((String) -> Unit)? = null
        fun post(t: String) {
            status = t
            Handler(Looper.getMainLooper()).post { listener?.invoke(t) }
        }
        fun postLevel(l: Int) {
            level = l
            Handler(Looper.getMainLooper()).post { levelListener?.invoke(l) }
        }
    }

    @Volatile private var running = false
    private var server: ServerSocket? = null
    @Volatile private var sock: Socket? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            "baby" -> { begin(true); startBaby() }
            "parent" -> { begin(false); startParent(i.getStringExtra("ip") ?: "") }
            else -> {
                release(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); post("Остановлено"); postLevel(0)
            }
        }
        return START_NOT_STICKY
    }

    private fun begin(baby: Boolean) {
        release(); running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mon", "Dryer Monitor", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "mon")
            .setContentTitle("Dryer Monitor работает")
            .setContentText(if (baby) "Режим сушилки: микрофон включён" else "Режим оператора: слушаю сушилку")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).setContentIntent(pi).build()
        if (Build.VERSION.SDK_INT >= 29) {
            val type = if (baby) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            startForeground(1, n, type)
        } else startForeground(1, n)
        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "babymon:wl").apply { acquire(12 * 60 * 60 * 1000L) }
        @Suppress("DEPRECATION")
        wifiLock = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "babymon:wifi").apply { acquire() }
    }

    private fun release() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        try { sock?.close() } catch (_: Exception) {}
        wake?.let { if (it.isHeld) it.release() }
        wifiLock?.let { if (it.isHeld) it.release() }
    }

    override fun onDestroy() { release(); super.onDestroy() }

    // ---------- Сушилка ----------
    private fun startBaby() {
        post("Режим сушилки\nIP: ${localIp()}\nМикрофон слушает.\nЖду подключения оператора…")
        thread {
            try {
                val ss = ServerSocket(PORT).also { server = it }
                while (running) {
                    val s = ss.accept()
                    try { sock?.close() } catch (_: Exception) {}
                    sock = s
                    post("Оператор подключён.\nIP: ${localIp()}")
                }
            } catch (e: Exception) { if (running) post("Ошибка: ${e.message}") }
        }
        thread { micLoop() }
    }

    // Микрофон слушает всегда; звук отправляется, только если оператор подключён
    private fun micLoop() {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, min * 2)
        val buf = ByteArray(min)
        try {
            rec.startRecording()
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) { post("Ошибка микрофона: $n"); break }
                if (n == 0) continue
                postLevel(levelOf(buf, n))
                val c = sock
                if (c != null) {
                    try { c.getOutputStream().write(buf, 0, n) }
                    catch (_: Exception) {
                        try { c.close() } catch (_: Exception) {}
                        if (sock === c) sock = null
                        post("Оператор отключился.\nЖду подключения…")
                    }
                }
            }
        } catch (e: Exception) { if (running) post("Ошибка микрофона: ${e.message}") }
        finally { try { rec.stop() } catch (_: Exception) {}; rec.release() }
    }

    // ---------- Оператор ----------
    private fun startParent(ipIn: String) {
        val ip = ipIn.ifEmpty { gatewayIp() }
        if (ip.isEmpty()) { post("Подключитесь к Wi-Fi сушилки или введите её IP"); return }
        post("Подключаюсь к $ip…")
        thread {
            try {
                val s = Socket().also { sock = it }
                s.connect(InetSocketAddress(ip, PORT), 5000)
                val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                    .setBufferSizeInBytes(min * 2).build()
                track.play()
                post("Слушаю сушилку")
                val inp = s.getInputStream()
                val buf = ByteArray(min)
                var lastAlert = 0L
                while (running) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    track.write(buf, 0, n)
                    val lv = levelOf(buf, n)
                    postLevel(lv)
                    if (lv >= threshold) {
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastAlert > 15000) { lastAlert = now; alertParent(lv) }
                    }
                }
                track.stop(); track.release()
                if (running) post("Соединение потеряно")
            } catch (e: Exception) { if (running) post("Ошибка: ${e.message}") }
        }
    }

    private fun rms(b: ByteArray, n: Int): Double {
        var sum = 0.0; var cnt = 0; var i = 0
        while (i + 1 < n) {
            val v = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt()
            sum += v.toDouble() * v; cnt++; i += 2
        }
        return if (cnt == 0) 0.0 else sqrt(sum / cnt)
    }

    private fun levelOf(b: ByteArray, n: Int): Int {
        val r = rms(b, n)
        if (r < 1) return 0
        val db = 20 * Math.log10(r / 32768.0)
        return (((db + 70) / 60) * 100).toInt().coerceIn(0, 100)
    }

    private fun alertParent(lv: Int) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alert", "Тревога", NotificationManager.IMPORTANCE_HIGH)
            .apply { enableVibration(true) })
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "alert")
            .setContentTitle("Сушилка шумит!")
            .setContentText("Громкость $lv% выше порога $threshold%")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentIntent(pi).setAutoCancel(true).build()
        nm.notify(2, n)
        vibrate()
    }

    private fun vibrate() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        v.vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    @Suppress("DEPRECATION")
    private fun gatewayIp(): String {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val g = wm.dhcpInfo?.gateway ?: 0
        return if (g == 0) "" else "${g and 0xFF}.${(g shr 8) and 0xFF}.${(g shr 16) and 0xFF}.${(g shr 24) and 0xFF}"
    }

    private fun localIp(): String = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }?.hostAddress ?: "?"
    } catch (_: Exception) { "?" }
}
