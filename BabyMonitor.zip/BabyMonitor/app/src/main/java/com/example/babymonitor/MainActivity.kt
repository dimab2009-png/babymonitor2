package com.example.babymonitor

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class LevelBar(c: Context) : View(c) {
    var level = 0
    var threshold = 50
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2A2E38") }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 5f }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = h / 2
        cv.drawRoundRect(0f, 0f, w, h, r, r, bg)
        if (level > 0) {
            fg.color = Color.parseColor(
                if (level >= threshold) "#FF5252" else if (level >= threshold * 0.7) "#FFC107" else "#2BB673")
            cv.drawRoundRect(0f, 0f, minOf(w, maxOf(w * level / 100f, h)), h, r, r, fg)
        }
        val x = w * threshold / 100f
        cv.drawLine(x, 0f, x, h, mark)
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var levelText: TextView
    private lateinit var bar: LevelBar
    private lateinit var card: LinearLayout
    private lateinit var ipField: EditText
    private lateinit var muteBtn: Button
    private var alertShown = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: String, r: Int) = GradientDrawable().apply {
        setColor(Color.parseColor(color)); cornerRadius = dp(r).toFloat()
    }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    // 3D-кнопка: нижняя «грань» + верхняя градиентная поверхность; при нажатии поверхность «вдавливается»
    private fun face(c1: String, c2: String, edge: String): StateListDrawable {
        fun layer(inTop: Int, inBottom: Int): LayerDrawable {
            val edgeD = GradientDrawable().apply {
                setColor(Color.parseColor(edge)); cornerRadius = dp(22).toFloat()
            }
            val topD = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor(c1), Color.parseColor(c2))).apply {
                cornerRadius = dp(22).toFloat(); setStroke(dp(1), Color.parseColor("#33FFFFFF"))
            }
            return LayerDrawable(arrayOf(edgeD, topD)).apply { setLayerInset(1, 0, dp(inTop), 0, dp(inBottom)) }
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), layer(5, 1))
            addState(intArrayOf(), layer(0, 6))
        }
    }

    private fun b3d(t: String, c1: String, c2: String, edge: String, size: Float, onClick: () -> Unit) =
        Button(this).apply {
            text = t; isAllCaps = false; textSize = size
            setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            background = face(c1, c2, edge); stateListAnimator = null
            minHeight = 0; minimumHeight = 0
            setPadding(dp(8), 0, dp(8), dp(6))
            setOnClickListener { onClick() }
        }

    private fun row(a: View, b: View, h: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, dp(h), 1f).apply { marginEnd = dp(7) })
        addView(b, LinearLayout.LayoutParams(0, dp(h), 1f).apply { marginStart = dp(7) })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0F1115")
        window.navigationBarColor = Color.parseColor("#0F1115")
        val prefs = getSharedPreferences("p", 0)
        val th0 = prefs.getInt("th2", 50)
        MonitorService.threshold = th0
        MonitorService.muted = prefs.getBoolean("mute", false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "Мониторинг сушилки"; textSize = 26f; setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "Слежение за звуком по Wi-Fi"; textSize = 14f
            setTextColor(Color.parseColor("#9AA0AA"))
        }, lp(2))

        // Карточка состояния и шкала звука
        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded("#1A1D24", 22)
        }
        status = TextView(this).apply { textSize = 18f; setTextColor(Color.WHITE) }
        levelText = TextView(this).apply {
            textSize = 14f; setTextColor(Color.parseColor("#9AA0AA")); text = "Громкость: 0%"
        }
        bar = LevelBar(this).apply { threshold = th0 }
        card.addView(status)
        card.addView(levelText, lp(8))
        card.addView(bar, LinearLayout.LayoutParams(-1, dp(30)).apply { topMargin = dp(12) })
        root.addView(card, lp(18))

        // Порог тревоги
        val thText = TextView(this).apply {
            textSize = 14f; setTextColor(Color.parseColor("#9AA0AA"))
            text = "Порог тревоги: $th0% (меньше = чувствительнее)"
        }
        val seek = SeekBar(this).apply {
            max = 94; progress = th0 - 1
            val tint = ColorStateList.valueOf(Color.parseColor("#4C8DFF"))
            progressTintList = tint; thumbTintList = tint
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val t = p + 1
                    MonitorService.threshold = t; bar.threshold = t; bar.invalidate()
                    thText.text = "Порог тревоги: $t% (меньше = чувствительнее)"
                    prefs.edit().putInt("th2", t).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        val thCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
            background = rounded("#1A1D24", 22)
        }
        thCard.addView(thText)
        thCard.addView(seek, lp(4))
        root.addView(thCard, lp(12))

        // Выбор режима: две большие 3D-кнопки
        val baby = b3d("🎙\nСушилка\nмикрофон", "#5B9CFF", "#3B7BEF", "#2154B8", 17f) { startBaby() }
        val op = b3d("🎧\nОператор\nслушать", "#3CCB85", "#23A468", "#157A4B", 17f) { startParent() }
        root.addView(row(baby, op, 124), lp(18))

        ipField = EditText(this).apply {
            hint = "IP сушилки (пусто = авто)"; textSize = 16f
            setHintTextColor(Color.parseColor("#6B7280")); setTextColor(Color.WHITE)
            background = rounded("#1A1D24", 18); setSingleLine()
            setPadding(dp(18), dp(14), dp(18), dp(14))
        }
        root.addView(ipField, lp(14))

        // Звук и стоп
        muteBtn = b3d("", "#3A3F4B", "#2C313B", "#1B1E25", 15f) {
            MonitorService.muted = !MonitorService.muted
            prefs.edit().putBoolean("mute", MonitorService.muted).apply()
            updateMute()
        }
        updateMute()
        val stop = b3d("⏹\nСтоп", "#FF6B6B", "#E53935", "#A52523", 15f) { send("stop") }
        root.addView(row(muteBtn, stop, 88), lp(14))
        root.addView(TextView(this).apply {
            text = "Без звука оповещения продолжают приходить"; textSize = 12f
            gravity = Gravity.CENTER; setTextColor(Color.parseColor("#6B7280"))
        }, lp(10))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0F1115")); isFillViewport = true; addView(root)
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    private fun updateMute() {
        val m = MonitorService.muted
        muteBtn.text = if (m) "🔇\nЗвук выкл" else "🔊\nЗвук вкл"
        muteBtn.setTextColor(Color.parseColor(if (m) "#1A1D24" else "#FFFFFF"))
        muteBtn.background = if (m) face("#FFB74D", "#F59E0B", "#B36B00") else face("#3A3F4B", "#2C313B", "#1B1E25")
    }

    private fun showLevel(l: Int) {
        bar.level = l; bar.invalidate()
        levelText.text = "Громкость: $l%"
        val loud = l >= bar.threshold
        if (loud != alertShown) {
            alertShown = loud
            card.background = rounded(if (loud) "#3A1C1F" else "#1A1D24", 22)
        }
    }

    override fun onStart() {
        super.onStart()
        status.text = MonitorService.status
        showLevel(MonitorService.level)
        MonitorService.listener = { status.text = it }
        MonitorService.levelListener = { showLevel(it) }
    }

    override fun onStop() {
        MonitorService.listener = null; MonitorService.levelListener = null; super.onStop()
    }

    private fun send(action: String, ip: String = "") {
        val i = Intent(this, MonitorService::class.java).setAction(action).putExtra("ip", ip)
        if (action == "stop") startService(i) else startForegroundService(i)
    }

    private fun startBaby() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        send("baby")
    }

    private fun startParent() = send("parent", ipField.text.toString().trim())

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (c == 1) {
            if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) send("baby")
            else status.text = "Нужен доступ к микрофону"
        }
    }
}
