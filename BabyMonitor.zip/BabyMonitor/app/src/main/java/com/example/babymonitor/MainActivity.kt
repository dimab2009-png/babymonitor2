package com.example.babymonitor

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import java.io.File
import kotlin.math.roundToInt

class Pal(val dark: Boolean) {
    val bg = if (dark) "#0F1115" else "#EEF1F6"
    val card = if (dark) "#1A1D24" else "#FFFFFF"
    val cardAlert = if (dark) "#3A1C1F" else "#FFE1E1"
    val text = if (dark) "#FFFFFF" else "#14171C"
    val sub = if (dark) "#9AA0AA" else "#5B6270"
    val hint = if (dark) "#6B7280" else "#8A93A3"
    val track = if (dark) "#101216" else "#CDD3DE"
    val off = if (dark) "#262A33" else "#DDE2EA"
    val gray1 = if (dark) "#3A3F4B" else "#F4F6FA"
    val gray2 = if (dark) "#2C313B" else "#D9DEE7"
    val grayEdge = if (dark) "#1B1E25" else "#A9B0BE"
    val grayText = if (dark) "#FFFFFF" else "#1A1D24"
}

// 3D-шкала звука: светодиодные сегменты с глянцем и отметкой порога
class LevelBar(c: Context, private val pal: Pal) : View(c) {
    var level = 0
    var threshold = 50
    private val d = resources.displayMetrics.density
    private val n = 20
    private val cols = arrayOf("#2BB673", "#FFE600", "#FF5252")
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#59FFFFFF") }
    private val mk = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor(pal.text) }
    private val tri = Path()
    private var shaders: Array<LinearGradient>? = null
    private var shH = -1

    private fun mix(c: Int, w: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * w).toInt(),
        (Color.green(c) + (255 - Color.green(c)) * w).toInt(),
        (Color.blue(c) + (255 - Color.blue(c)) * w).toInt())

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val top = 12 * d
        if (shaders == null || shH != height) {
            shH = height
            shaders = Array(3) {
                val c = Color.parseColor(cols[it])
                LinearGradient(0f, top, 0f, h, mix(c, 0.4f), c, Shader.TileMode.CLAMP)
            }
        }
        val gap = 3 * d; val sw = (w - gap * (n - 1)) / n; val rad = 4 * d
        val offC = Color.parseColor(pal.off)
        for (i in 0 until n) {
            val pos = (i + 0.5f) / n * 100f
            val ci = if (pos >= threshold) 2 else if (pos >= threshold * 0.7f) 1 else 0
            cv.save(); cv.translate(i * (sw + gap), 0f)
            if (pos <= level) {
                val c = Color.parseColor(cols[ci])
                paint.shader = null; paint.color = Color.argb(70, Color.red(c), Color.green(c), Color.blue(c))
                cv.drawRoundRect(-2 * d, top - 2 * d, sw + 2 * d, h + 2 * d, rad + 2 * d, rad + 2 * d, paint)
                paint.shader = shaders!![ci]
                cv.drawRoundRect(0f, top, sw, h, rad, rad, paint)
                paint.shader = null
                cv.drawRoundRect(1.5f * d, top + 1.5f * d, sw - 1.5f * d, top + (h - top) * 0.4f, rad, rad, hl)
            } else {
                paint.shader = null; paint.style = Paint.Style.FILL; paint.color = offC
                cv.drawRoundRect(0f, top, sw, h, rad, rad, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.5f * d
                paint.color = Color.parseColor(if (pal.dark) "#3B4150" else "#B5BCCB")
                cv.drawRoundRect(0f, top, sw, h, rad, rad, paint)
                paint.style = Paint.Style.FILL
            }
            cv.restore()
        }
        val mx = w * threshold / 100f
        cv.drawRect(mx - 1.5f * d, top - 2 * d, mx + 1.5f * d, h, mk)
        tri.reset(); tri.moveTo(mx - 6 * d, 0f); tri.lineTo(mx + 6 * d, 0f); tri.lineTo(mx, 9 * d); tri.close()
        cv.drawPath(tri, mk)
    }
}

// 3D-ползунок: углублённая дорожка и объёмный шарик
class Slider3D(c: Context, private val pal: Pal) : View(c) {
    var min = 1
    var max = 95
    var value = 50
    var onChange: ((Int) -> Unit)? = null
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun geo() = Triple(20 * d, width - 20 * d, height / 2f)

    override fun onDraw(cv: Canvas) {
        val (x0, x1, cy) = geo()
        val gh = 12 * d; val r = 15 * d
        val tx = x0 + (x1 - x0) * (value - min) / (max - min).toFloat()
        paint.shader = null; paint.color = Color.parseColor(pal.track)
        cv.drawRoundRect(x0, cy - gh / 2, x1, cy + gh / 2, gh / 2, gh / 2, paint)
        paint.color = Color.argb(80, 0, 0, 0)
        cv.drawRoundRect(x0, cy - gh / 2, x1, cy - gh / 2 + 3 * d, gh / 2, gh / 2, paint)
        paint.shader = LinearGradient(0f, cy - gh / 2, 0f, cy + gh / 2,
            Color.parseColor("#7DB2FF"), Color.parseColor("#3B7BEF"), Shader.TileMode.CLAMP)
        cv.drawRoundRect(x0, cy - gh / 2, tx, cy + gh / 2, gh / 2, gh / 2, paint)
        paint.shader = null
        paint.color = Color.argb(70, 255, 255, 255)
        cv.drawRoundRect(x0 + 2 * d, cy - gh / 2 + 1.5f * d, maxOf(tx - 2 * d, x0 + 2 * d), cy - 1 * d, 3 * d, 3 * d, paint)
        paint.color = Color.argb(95, 0, 0, 0)
        cv.drawCircle(tx, cy + 4 * d, r + d, paint)
        paint.color = Color.parseColor("#2154B8")
        cv.drawCircle(tx, cy, r, paint)
        paint.shader = RadialGradient(tx - r * 0.3f, cy - r * 0.4f, r * 1.3f,
            intArrayOf(Color.WHITE, Color.parseColor("#9CC3FF"), Color.parseColor("#3B7BEF")),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(tx, cy, r - 2 * d, paint)
        paint.shader = null
    }

    private fun setFromX(x: Float) {
        val (x0, x1, _) = geo()
        val ratio = ((x - x0) / (x1 - x0)).coerceIn(0f, 1f)
        val v = (min + ratio * (max - min)).roundToInt()
        if (v != value) { value = v; invalidate(); onChange?.invoke(v) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true); setFromX(e.x)
            }
            MotionEvent.ACTION_UP -> { parent?.requestDisallowInterceptTouchEvent(false); performClick() }
            MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()
}

class MainActivity : AppCompatActivity() {
    private lateinit var pal: Pal
    private lateinit var status: TextView
    private lateinit var levelText: TextView
    private lateinit var bar: LevelBar
    private lateinit var card: LinearLayout
    private lateinit var ipField: EditText
    private lateinit var muteBtn: Button
    private var alertShown = false
    private var torchOn = false
    private var torchId: String? = null
    private var torchCb: CameraManager.TorchCallback? = null
    // Ссылка для благодарности (Т-Банк, Сбер, ЮMoney, Boosty и т.п.). Пока пусто, показывается «Спасибо!»
    private val donateUrl = ""

    private fun col(s: String) = Color.parseColor(s)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: String, r: Int) = GradientDrawable().apply {
        setColor(col(color)); cornerRadius = dp(r).toFloat()
    }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    // 3D-кнопка: нижняя «грань» + верхняя градиентная поверхность; при нажатии поверхность вдавливается
    private fun face(c1: String, c2: String, edge: String): StateListDrawable {
        fun layer(inTop: Int, inBottom: Int): LayerDrawable {
            val edgeD = GradientDrawable().apply { setColor(col(edge)); cornerRadius = dp(22).toFloat() }
            val topD = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(col(c1), col(c2))).apply {
                cornerRadius = dp(22).toFloat(); setStroke(dp(1), col("#33FFFFFF"))
            }
            return LayerDrawable(arrayOf(edgeD, topD)).apply { setLayerInset(1, 0, dp(inTop), 0, dp(inBottom)) }
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), layer(5, 1))
            addState(intArrayOf(), layer(0, 6))
        }
    }

    private fun b3d(t: String, c1: String, c2: String, edge: String, size: Float, onClick: () -> Unit) =
        Button(this).apply {
            text = t; isAllCaps = false; textSize = size
            setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            background = face(c1, c2, edge); stateListAnimator = null
            minHeight = 0; minimumHeight = 0
            setPadding(dp(8), 0, dp(8), dp(6))
            setOnClickListener { onClick() }
        }

    private fun row(a: View, b: View, h: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, dp(h), 1f).apply { marginEnd = dp(7) })
        addView(b, LinearLayout.LayoutParams(0, dp(h), 1f).apply { marginStart = dp(7) })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", 0)
        pal = Pal(prefs.getBoolean("dark", true))
        window.statusBarColor = col(pal.bg)
        window.navigationBarColor = col(pal.bg)
        WindowCompat.getInsetsController(window, window.decorView)?.apply {
            isAppearanceLightStatusBars = !pal.dark
            isAppearanceLightNavigationBars = !pal.dark
        }
        val th0 = prefs.getInt("th5", 55)
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            torchId = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            torchCb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(id: String, enabled: Boolean) { if (id == torchId) torchOn = enabled }
            }
            cm.registerTorchCallback(torchCb!!, null)
        } catch (_: Exception) {}
        MonitorService.threshold = th0
        MonitorService.muted = prefs.getBoolean("mute", false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        // Заголовок и меню «три точки»
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(40), 0, dp(40), 0)
        }
        titles.addView(TextView(this).apply {
            text = "Мониторинг сушилки"; textSize = 24f; setTypeface(null, Typeface.BOLD)
            setTextColor(col(pal.text))
        })
        titles.addView(TextView(this).apply {
            text = "Слежение за звуком по Wi-Fi"; textSize = 14f; setTextColor(col(pal.sub))
            gravity = Gravity.CENTER
        }, lp(2))
        val dots = TextView(this).apply {
            text = "⋮"; textSize = 30f; setTypeface(null, Typeface.BOLD)
            setTextColor(col(pal.text)); gravity = Gravity.CENTER
            setPadding(dp(14), dp(2), dp(6), dp(2))
            setOnClickListener { showMenu(it, prefs) }
        }
        root.addView(FrameLayout(this).apply {
            addView(titles, FrameLayout.LayoutParams(-1, -2))
            addView(dots, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        })

        // Карточка состояния и 3D-шкала звука
        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(pal.card, 22)
        }
        status = TextView(this).apply { textSize = 16f; setTextColor(col(pal.text)) }
        levelText = TextView(this).apply {
            textSize = 26f; setTypeface(null, Typeface.BOLD); setTextColor(col("#2BB673")); text = "Громкость: 0%"
        }
        bar = LevelBar(this, pal).apply { threshold = th0 }
        card.addView(status)
        card.addView(levelText, lp(8))
        card.addView(bar, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(12) })
        root.addView(card, lp(12))

        // Порог тревоги: 3D-ползунок
        val thText = TextView(this).apply {
            textSize = 14f; setTextColor(col(pal.sub))
            text = "Порог тревоги: $th0% (меньше = чувствительнее)"
        }
        val slider = Slider3D(this, pal).apply {
            value = th0
            onChange = { t ->
                MonitorService.threshold = t; bar.threshold = t; bar.invalidate()
                thText.text = "Порог тревоги: $t% (меньше = чувствительнее)"
                prefs.edit().putInt("th5", t).apply()
            }
        }
        val thCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(8))
            background = rounded(pal.card, 22)
        }
        thCard.addView(thText)
        thCard.addView(slider, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(4) })
        root.addView(thCard, lp(12))

        // Выбор режима
        val baby = b3d("🎙\nСушилка", "#5B9CFF", "#3B7BEF", "#2154B8", 17f) { startBaby() }
        val op = b3d("🎧\nОператор", "#3CCB85", "#23A468", "#157A4B", 17f) { startParent() }
        root.addView(row(baby, op, 124), lp(14))

        ipField = EditText(this).apply {
            hint = "IP сушилки (пусто = авто)"; textSize = 16f
            setHintTextColor(col(pal.hint)); setTextColor(col(pal.text))
            background = rounded(pal.card, 18); setSingleLine()
            setPadding(dp(18), dp(14), dp(18), dp(14))
        }
        root.addView(ipField, lp(12))

        // Звук и стоп
        muteBtn = b3d("", pal.gray1, pal.gray2, pal.grayEdge, 15f) {
            MonitorService.muted = !MonitorService.muted
            prefs.edit().putBoolean("mute", MonitorService.muted).apply()
            updateMute()
        }
        updateMute()
        val stop = b3d("⏹\nСтоп", "#FF6B6B", "#E53935", "#A52523", 15f) { send("stop") }
        root.addView(row(muteBtn, stop, 88), lp(12))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(col(pal.bg)); isFillViewport = true; addView(root)
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    private fun showMenu(v: View, prefs: android.content.SharedPreferences) {
        val m = PopupMenu(this, v)
        m.menu.add(0, 1, 0, if (pal.dark) "☀  Светлая тема" else "🌙  Тёмная тема")
        m.menu.add(0, 2, 1, if (torchOn) "🔦  Выключить фонарик" else "🔦  Включить фонарик")
        m.menu.add(0, 3, 2, "📤  Поделиться приложением")
        m.menu.add(0, 4, 3, "🍺  Поблагодарить литрушкой пива")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> { prefs.edit().putBoolean("dark", !pal.dark).apply(); recreate() }
                2 -> toggleTorch()
                3 -> shareApp()
                4 -> donate()
            }
            true
        }
        m.show()
    }

    private fun toggleTorch() {
        val id = torchId
        if (id == null) { Toast.makeText(this, "На этом телефоне нет фонарика", Toast.LENGTH_SHORT).show(); return }
        try {
            (getSystemService(Context.CAMERA_SERVICE) as CameraManager).setTorchMode(id, !torchOn)
        } catch (e: Exception) {
            Toast.makeText(this, "Фонарик недоступен: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun donate() {
        if (donateUrl.isBlank()) {
            Toast.makeText(this, "Спасибо! 🍺", Toast.LENGTH_LONG).show()
        } else {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(donateUrl))) }
            catch (_: Exception) { Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show() }
        }
    }

    // Отправляет установочный файл этого приложения (APK) через любой мессенджер или Bluetooth
    private fun shareApp() {
        try {
            val dir = File(cacheDir, "share").apply { mkdirs() }
            val out = File(dir, "Sushilka.apk")
            File(applicationInfo.sourceDir).copyTo(out, overwrite = true)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", out)
            val i = Intent(Intent.ACTION_SEND).setType("application/vnd.android.package-archive")
                .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Поделиться приложением"))
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось поделиться: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun updateMute() {
        val m = MonitorService.muted
        muteBtn.text = if (m) "🔇\nЗвук выкл" else "🔊\nЗвук вкл"
        muteBtn.setTextColor(col(if (m) "#1A1D24" else pal.grayText))
        muteBtn.background = if (m) face("#FFB74D", "#F59E0B", "#B36B00") else face(pal.gray1, pal.gray2, pal.grayEdge)
    }

    private fun showLevel(l: Int) {
        bar.level = l; bar.invalidate()
        levelText.text = "Громкость: $l%"
        levelText.setTextColor(col(
            if (l >= bar.threshold) "#FF5252"
            else if (l >= bar.threshold * 0.7) (if (pal.dark) "#FFE600" else "#D49A00")
            else "#2BB673"))
        val loud = l >= bar.threshold
        if (loud != alertShown) {
            alertShown = loud
            card.background = rounded(if (loud) pal.cardAlert else pal.card, 22)
        }
    }

    override fun onStart() {
        super.onStart()
        status.text = MonitorService.status
        showLevel(MonitorService.level)
        MonitorService.listener = { status.text = it }
        MonitorService.levelListener = { showLevel(it) }
    }

    override fun onStop() {
        MonitorService.listener = null; MonitorService.levelListener = null; super.onStop()
    }

    override fun onDestroy() {
        torchCb?.let {
            try { (getSystemService(Context.CAMERA_SERVICE) as CameraManager).unregisterTorchCallback(it) }
            catch (_: Exception) {}
        }
        super.onDestroy()
    }

    private fun send(action: String, ip: String = "") {
        val i = Intent(this, MonitorService::class.java).setAction(action).putExtra("ip", ip)
        if (action == "stop") startService(i) else startForegroundService(i)
    }

    private fun startBaby() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        send("baby")
    }

    private fun startParent() = send("parent", ipField.text.toString().trim())

    override fun onRequestPermissionsResult(c: Int, perms: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, perms, r)
        if (c == 1) {
            if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) send("baby")
            else status.text = "Нужен доступ к микрофону"
        }
    }
}
