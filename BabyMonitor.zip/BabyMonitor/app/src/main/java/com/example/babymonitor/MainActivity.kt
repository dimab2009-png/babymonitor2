package com.example.babymonitor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var ipField: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply { textSize = 20f; gravity = Gravity.CENTER }
        ipField = EditText(this).apply { hint = "IP малыша (пусто = авто, если малыш раздаёт точку доступа)" }
        val baby = Button(this).apply { text = "Режим малыша (микрофон)"; setOnClickListener { startBaby() } }
        val parent = Button(this).apply { text = "Режим родителя (слушать)"; setOnClickListener { startParent() } }
        val stop = Button(this).apply { text = "Стоп"; setOnClickListener { send("stop") } }
        listOf(status, baby, ipField, parent, stop).forEach { root.addView(it) }
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    override fun onStart() {
        super.onStart()
        status.text = MonitorService.status
        MonitorService.listener = { status.text = it }
    }

    override fun onStop() { MonitorService.listener = null; super.onStop() }

    private fun send(action: String, ip: String = "") {
        val i = Intent(this, MonitorService::class.java).setAction(action).putExtra("ip", ip)
        if (action == "stop") startService(i) else startForegroundService(i)
    }

    private fun startBaby() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        send("baby")
    }

    private fun startParent() = send("parent", ipField.text.toString().trim())

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (c == 1) {
            if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) send("baby")
            else status.text = "Нужен доступ к микрофону"
        }
    }
}
